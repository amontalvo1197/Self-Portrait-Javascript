function setup() {
  angleMode(DEGREES);//for smile
  createCanvas(400, 400);
  background(232,188,231);//pink
  
  //hair
  fill(133, 124, 99) //hair color
  rect(87,55,230,330,110) //hair
  
  //neck
  fill(252, 235, 174);//skin color neck
  rect(175,234,50,40)//neck
  point(200,200)
  
  //head
  fill(252, 235, 174);//skin color
  ellipse(200,150,150,175)
  
    //nose
  fill(252, 235, 174)//nose color
  arc(198,175,25,15,270,90)//nose
  
  //bangs
  fill(133, 124, 99)
  rect(150,60,95,43,57)
  
  
  //eyes 
  //left and right eye whites
  fill(255,255)
  ellipse(165,145,55,30)
  ellipse(235,145,55,30)
  
  //eye color right
  fill(99, 64, 17)
  ellipse(235,145,25,27)//eye color
  fill(0)
  ellipse(235,145,15,17) //eye shine
  fill(255)
  ellipse(238,140,5,7)//pupil
  
  //eye color left
  fill(99, 64, 17)
  ellipse(165,145,25,27)//eye color
  fill(0)
  ellipse(165,145,15,17)//eye shine
  //eye shine
  fill(255)
  ellipse(168,140,5,7)//pupil
  
  //mouth
  fill(217, 85, 144)//mouth color
  arc(200,192,50,50,0,180)//mouth
  
  //eyebrows
  strokeWeight(3) //brow thickness
  stroke(133, 124, 99) //brow color
  line(150,115,175,112) //left brow
  line(220,115,250,118) //right brow
  strokeWeight(1) //brow outline line thiccness
  stroke(133, 124, 99) //brow outline color
  
  //hair
  

  
  
  
  
  
  
  
  
}